package edu.curtin.imageviewer;
import java.util.*;

/**
 * Represents an album of images.
 */
public class Album 
{
    private List<ImageRecord> image;

    public Album()
    {
        this.image = new ArrayList<>();
    }

    public void addImage(ImageRecord photo)
    {
        if(photo == null)
        {
            throw new IllegalArgumentException("Image Record doesn't exist");
        }
        else
        {
            this.image.add(photo);
        }
    }

    public ImageRecord getImage(int index)
    {
        if(index >= this.image.size())
        {
            throw new IndexOutOfBoundsException("Index can't be greater than the size of the array (" + image.size() + ")");
        }
        else if(index < 0)
        {
            throw new IndexOutOfBoundsException("Index can't be less than 0");
        }
        else
        {
            return image.get(index);
        }
    }

    public int getSize()
    {
        return image.size();
    }
}